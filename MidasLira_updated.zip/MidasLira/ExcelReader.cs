using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public class ExcelReader
{
    public List<MidasNodeInfo> Read(string filePath)
    {
        if (string.IsNullOrWhiteSpace(filePath) || !File.Exists(filePath))
            throw new FileNotFoundException("Файл Excel не найден.", filePath);

        ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

        using (var package = new ExcelPackage(new FileInfo(filePath)))
        {
            if (package.Workbook.Worksheets.Count == 0)
                throw new InvalidOperationException("Файл Excel не содержит листов.");

            var worksheet = package.Workbook.Worksheets.FirstOrDefault(ws =>
                ws.Name.Equals("Sheet1", StringComparison.OrdinalIgnoreCase)
                || ws.Name.Equals("Nodes", StringComparison.OrdinalIgnoreCase));

            if (worksheet == null || worksheet.Dimension == null)
                throw new InvalidOperationException("Ожидаемый лист Excel не найден или пуст.");

            int rows = worksheet.Dimension.Rows;
            var nodes = new List<MidasNodeInfo>();

            for (int row = 2; row <= rows; row++)
            {
                if (worksheet.Cells[row, 1].Value == null)
                    continue;

                var node = new MidasNodeInfo
                {
                    Id = Convert.ToInt32(worksheet.Cells[row, 1].Value),
                    X = Convert.ToDouble(worksheet.Cells[row, 2].Value ?? 0),
                    Y = Convert.ToDouble(worksheet.Cells[row, 3].Value ?? 0),
                    Z = Convert.ToDouble(worksheet.Cells[row, 4].Value ?? 0)
                };
                nodes.Add(node);
            }

            return nodes;
        }
    }
}
