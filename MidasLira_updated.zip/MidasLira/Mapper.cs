using System.Collections.Generic;
using System.Linq;

public class Mapper
{
    public List<List<MidasElementInfo>> GroupElements(List<MidasElementInfo> elements)
    {
        var result = new List<List<MidasElementInfo>>();
        var processedElements = new HashSet<int>();

        foreach (var element in elements)
        {
            if (!processedElements.Add(element.Id))
                continue;

            var group = new List<MidasElementInfo> { element };

            foreach (var other in elements)
            {
                if (other.Id == element.Id)
                    continue;

                var nodeSet = new HashSet<int>(element.NodeIds);
                if (other.NodeIds.Any(nodeSet.Contains))
                {
                    if (processedElements.Add(other.Id))
                        group.Add(other);
                }
            }

            result.Add(group);
        }

        return result;
    }
}
