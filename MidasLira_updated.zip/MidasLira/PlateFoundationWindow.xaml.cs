using System;
using System.Threading.Tasks;
using System.Windows;

public partial class PlateFoundationWindow : Window
{
    private readonly DataProcessor _dataProcessor;

    public PlateFoundationWindow()
    {
        InitializeComponent();
        _dataProcessor = new DataProcessor();
    }

    private async void ProcessButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            ProcessButton.IsEnabled = false;
            ProgressBar.Visibility = Visibility.Visible;

            var result = await Task.Run(() => _dataProcessor.Process(excelPath, liraPath));

            MessageBox.Show(result ? "Обработка завершена" : "Ошибка при обработке",
                "MidasLira", MessageBoxButton.OK,
                result ? MessageBoxImage.Information : MessageBoxImage.Error);
        }
        catch (Exception ex)
        {
            MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            ProgressBar.Visibility = Visibility.Collapsed;
            ProcessButton.IsEnabled = true;
        }
    }
}
